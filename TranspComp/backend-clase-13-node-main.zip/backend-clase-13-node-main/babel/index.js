const array = [1, 2, 3, 4, 5];

array.map(valor => valor*2).forEach(valor => console.log(valor))