import { suma, resta } from './example1.js';

console.log(suma(2, 3))
console.log(resta(2, 3))