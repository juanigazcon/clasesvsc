export const suma = (num1, num2) => {
    return num1 + num2
}

export const resta = (num1, num2) => {
    return num1 - num2
}
